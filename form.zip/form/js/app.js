function control() { //Fonction Control()
    
var formulaire = document.getElementById("formulaire") //Formulaire
var verif = "oui" //Verification 

var nom = document.getElementById("nom")//Formulaire nom
var prenom = document.getElementById("prenom")//Formulaire prenom
var date = document.getElementById("date")//Formulaire date

var paragraph_nom = document.getElementById("paragraph_nom") //Ajouter un paragraph dans le code HTML
var paragraph_prenom = document.getElementById("paragraph_prenom") //Ajouter un paragraph dans le code HTML
var paragraph_date = document.getElementById("paragraph_date") //Ajouter un paragraph dans le code HTML

   if (nom.value == "") { //Si il n'y a pas de nom
     nom.style.borderColor = "red" //Border en rouge
     paragraph_nom.innerHTML = "Veuillez renseigner un nom"//Renseigne un nom
     verif = "non"
     return false; //Retourne une valeur fausse
   }
   if (prenom.value == "") { //Si il n'y a pas de nom
     prenom.style.borderColor = "red" //Border en rouge
     paragraph_prenom.innerHTML = "Veuillez renseigner un prenom"//Renseigne un prenom
     verif = "non"
     return false; //Retourne une valeur fausse
   }
   if (date.value == "") { //Si il n'y a pas de nom
     date.style.borderColor = "red" //Border en rouge
     paragraph_date.innerHTML = "Veuillez renseigner une date"//Renseigne une date
       verif = "non"
     return false; //Retourne une valeur fausse
   }
    else if (verif == "oui") { //Verification
        formulaire.submit() //Envoi..GOOD!
    }
    
}